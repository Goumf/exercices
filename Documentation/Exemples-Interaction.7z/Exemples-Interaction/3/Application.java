public class  Application
{
	
	public static void main(String param[])
	{
		FenetrePrincipale win;
		win = new FenetrePrincipale("Fenêtre avec Menu", 800, 600);
	} // Fin de la méthode de test main()
} //Fin de la classe Application
