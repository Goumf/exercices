public class TemperatureController {
    private TemperatureModel model;

    public TemperatureController(TemperatureModel model) {
        this.model = model;
    }

    public void setCelsius(double value) {
        model.setCelsius(value);
    }

    public void setFahrenheit(double value) {
        model.setFahrenheit(value);
    }
}